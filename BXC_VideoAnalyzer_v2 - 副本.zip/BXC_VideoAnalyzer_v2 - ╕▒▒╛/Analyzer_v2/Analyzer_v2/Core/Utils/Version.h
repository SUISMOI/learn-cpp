﻿#ifndef ANALYZER_VERSION_H
#define ANALYZER_VERSION_H
namespace AVSAnalyzer {
#define PROJECT_VERSION "Analyzer v2"

}
#endif //ANALYZER_VERSION_H