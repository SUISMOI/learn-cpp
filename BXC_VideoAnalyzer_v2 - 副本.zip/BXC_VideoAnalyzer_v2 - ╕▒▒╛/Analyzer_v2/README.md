###### Analyzer

#### 介绍
视频流实时分析器


#### 编译
~~~
windows版支持 x64/Release,x64/Debug
linux

~~~

#### 第三方库

1.  ffmpeg
2.  curl
3.  event
4.  jpeg-turbo
5.  jsoncpp
6.  opencv


